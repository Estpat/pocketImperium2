package model;


import java.util.*;

/**
 * Commande Exterminer : Permet d'envahir les systèmes adjacents avec des vaisseaux.
 */
public class Exterminate extends CommandCard {
    private int nombreInvasions; // Nombre de systèmes que le joueur peut envahir ce tour

    /**
     * Constructeur de la commande Exterminer
     * 
     * @param joueur          Le joueur exécutant la commande
     * @param nombreInvasions Nombre d'invasions autorisées
     */
    public Exterminate (Joueur joueur, int nombreInvasions) {
        super("Exterminer", joueur); // Appelle le constructeur de la classe mère CommandCard
        this.nombreInvasions = nombreInvasions;
    }

    @Override
    public void executerEffet() {
        Joueur joueur = getJoueur();
        System.out.println("Commande Exterminer exécutée pour le joueur " + joueur.getName());
        Scanner scanner = new Scanner(System.in);
        int invasionsRestantes = nombreInvasions;

        // Tant qu'il reste des invasions autorisées
        while (invasionsRestantes > 0) {
            // Liste des hexagones contrôlés par le joueur
            List<Hexagone> hexagonesContrôlés = joueur.getHexagonesContrôlés();

            // Choix de l'hexagone à envahir
            System.out.println("Sélectionnez l'hexagone cible à envahir :");
            Hexagone cible = choisirHexagoneCible(hexagonesContrôlés, scanner);

            // Si la cible n'est pas valide ou contrôlée par le joueur, retour au début
            if (cible == null || cible.getContrôleur() == joueur) {
                System.out.println("Cible invalide. Sélectionnez un hexagone que vous ne contrôlez pas.");
                continue;
            }

            // Création de la flotte d'invasion
            int vaisseauxInvasion = déplacerVaisseauxVersCible(joueur, cible, scanner);

            // Si aucun vaisseau n'a été déplacé, retour au début
            if (vaisseauxInvasion <= 0) {
                System.out.println("Aucun vaisseau n'a été déplacé. Sélectionnez une autre cible.");
                continue;
            }

            // Résolution de l'invasion
            résoudreInvasion(joueur, cible, vaisseauxInvasion);

            // Réduction du nombre d'invasions restantes
            invasionsRestantes--;
            System.out.println("Invasions restantes : " + invasionsRestantes);
        }

        System.out.println("Toutes les invasions autorisées ont été effectuées.");
    }

    private Hexagone choisirHexagoneCible(List<Hexagone> hexagonesContrôlés, Scanner scanner) {
        for (int i = 0; i < hexagonesContrôlés.size(); i++) {
            System.out.println((i + 1) + ". " + hexagonesContrôlés.get(i).getId());
        }
        int choix = scanner.nextInt() - 1;
        if (choix >= 0 && choix < hexagonesContrôlés.size()) {
            return hexagonesContrôlés.get(choix);
        }
        return null;
    }

    private int déplacerVaisseauxVersCible(Joueur joueur, Hexagone cible, Scanner scanner) {
        List<Hexagone> hexagonesAdjacents = cible.getVoisins();
        int totalVaisseaux = 0;

        // Sélectionner des vaisseaux depuis les hexagones adjacents
        for (Hexagone voisin : hexagonesAdjacents) {
            if (voisin.getContrôleur() == joueur && voisin.getVaisseaux() > 0) {
                System.out.println("Hexagone " + voisin.getId() + " - Vaisseaux disponibles : " + voisin.getVaisseaux());
                System.out.println("Combien de vaisseaux voulez-vous déplacer depuis cet hexagone ?");
                int vaisseauxDéplacés = scanner.nextInt();

                if (vaisseauxDéplacés > 0 && vaisseauxDéplacés <= voisin.getVaisseaux()) {
                    voisin.retirerVaisseaux(vaisseauxDéplacés);
                    totalVaisseaux += vaisseauxDéplacés;
                } else {
                    System.out.println("Nombre invalide. Aucun vaisseau déplacé depuis cet hexagone.");
                }
            }
        }
        return totalVaisseaux;
    }

    private void résoudreInvasion(Joueur joueur, Hexagone cible, int vaisseauxInvasion) {
        Joueur défenseur = cible.getContrôleur();
        int vaisseauxDéfense = cible.getVaisseaux();

        if (défenseur != null) {
            System.out.println("Résolution de l'invasion :");
            System.out.println("Vaisseaux en attaque : " + vaisseauxInvasion);
            System.out.println("Vaisseaux en défense : " + vaisseauxDéfense);

            // Calcul des pertes
            int pertes = Math.min(vaisseauxInvasion, vaisseauxDéfense);
            vaisseauxInvasion -= pertes;
            vaisseauxDéfense -= pertes;

            System.out.println("Pertes pour l'attaquant : " + pertes);
            System.out.println("Pertes pour le défenseur : " + pertes);

            // Mise à jour de la situation
            cible.setVaisseaux(vaisseauxDéfense);
            if (vaisseauxDéfense == 0 && vaisseauxInvasion > 0) {
                cible.setContrôleur(joueur);
                cible.ajouterVaisseaux(vaisseauxInvasion);
                System.out.println("L'attaquant prend le contrôle de l'hexagone " + cible.getId());
            } else if (vaisseauxDéfense == 0 && vaisseauxInvasion == 0) {
                cible.setContrôleur(null);
                System.out.println("L'hexagone " + cible.getId() + " est laissé inoccupé.");
            }
        } else {
            System.out.println("Envahissement d'un système inoccupé.");
            cible.setContrôleur(joueur);
            cible.ajouterVaisseaux(vaisseauxInvasion);
        }
    }
}
