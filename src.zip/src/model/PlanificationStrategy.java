package model;

public interface PlanificationStrategy {
	void planifier(JoueurCPU joueur);

}
