package model;

import java.util.ArrayList;
import java.util.List;

import controller.GameController;
import view.ConsoleView;

public class Partie {
    private List<Joueur> joueurs;
    private MarqueurDeSecteurs marqueurDeSecteurs;
    private DispositionSecteurs disposition;
    private boolean estTerminee;

    public Partie(List<Joueur> joueurs, DispositionSecteurs disposition) {
        this.joueurs = joueurs;
        this.disposition = disposition;
        this.marqueurDeSecteurs = new MarqueurDeSecteurs(disposition, joueurs);
        this.estTerminee = false;
    }

    public void commencer() {
        System.out.println("Début de la partie !");
        while (!estTerminee) {
            for (Joueur joueur : joueurs) {
                if (!estTerminee) {
                    joueur.planification(); // Chaque joueur effectue sa phase de planification
                    marqueurDeSecteurs.marquerSecteurs(); // Marquage des secteurs
                    // Ajouter la logique de jeu pour un tour complet
                    // Par exemple, les actions du joueur, vérification de la victoire, etc.
                    checkFinDePartie(); // Vérifie si la partie est terminée
                }
            }
        }
    }

    private void checkFinDePartie() {
        // Implémenter la logique de fin de partie, comme un joueur qui gagne
        // Par exemple, si tous les secteurs sont contrôlés, la partie se termine
        for (Joueur joueur : joueurs) {
            // Ajouter une condition de victoire
            if (joueur.aGagne()) {
                System.out.println(joueur.getName() + " a gagné la partie !");
                estTerminee = true;
                break;
            }
        }
    }
    
        public static void main(String[] args) {
            // Créer les joueurs
            List<Joueur> joueurs = new ArrayList<>();
            joueurs.add(new JoueurReel("Joueur 1"));
            joueurs.add(new JoueurCPU("Joueur CPU", new StrategieAleatoire()));

            // Créer la disposition des secteurs
            DispositionSecteurs disposition = new DispositionSecteurs();

            // Créer la vue et le contrôleur
            ConsoleView view = new ConsoleView();
            Partie partie = new Partie(joueurs, disposition);
            GameController controller = new GameController(partie, view);

            // Lancer la partie
            controller.lancerJeu();
        }
    

}
