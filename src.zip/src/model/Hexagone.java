package model;

import java.util.*;

/**
 * Classe pour représenter un hexagone dans la grille de jeu.
 */
public class Hexagone {
    private String id; // Identifiant unique de l'hexagone (ex : "A1", "B2")
    private Systeme système; // Système contenu dans cet hexagone (null si aucun)
    private Joueur contrôleur; // Joueur qui contrôle cet hexagone
    private int q; // Coordonnée Q dans la grille hexagonale
    private int r; // Coordonnée R dans la grille hexagonale
    private List<Hexagone> voisins; // Hexagones adjacents
    private boolean estDemiHexagone; // Indique si cet hexagone est un demi-hexagone
    private int vaisseaux = 0; // Nombre de vaisseaux présents sur l'hexagone

    // Constructeur
    public Hexagone(String id, int q, int r, boolean estDemiHexagone) {
        this.id = id;
        this.q = q;
        this.r = r;
        this.voisins = new ArrayList<>();
        this.estDemiHexagone = estDemiHexagone;
    }

    // Getter et setter pour l'identifiant
    public String getId() {
        return id;
    }

    // Gestion du système
    public Systeme getSysteme() {
        return système;
    }

    public void setSysteme(Systeme système) {
        this.système = système;
    }

    // Gestion du contrôleur
    public Joueur getContrôleur() {
        return contrôleur;
    }

    public void setContrôleur(Joueur contrôleur) {
        this.contrôleur = contrôleur;
    }

    // Coordonnées dans la grille
    public int getQ() {
        return q;
    }

    public int getR() {
        return r;
    }

    // Gestion des voisins
    public List<Hexagone> getVoisins() {
        return voisins;
    }

    public void ajouterVoisin(Hexagone voisin) {
        voisins.add(voisin);
    }

    // Vérifie si l'hexagone est un hexagone de système
    public boolean estHexagoneDeSystème() {
        return système != null;
    }

    // Vérifie si l'hexagone est un demi-hexagone
    public boolean estDemiHexagone() {
        return estDemiHexagone;
    }

    // Calcul de la distance à un autre hexagone
    public int calculerDistance(Hexagone autre) {
        int dq = Math.abs(this.q - autre.q);
        int dr = Math.abs(this.r - autre.r);
        int ds = Math.abs((-this.q - this.r) - (-autre.q - autre.r));
        return Math.max(dq, Math.max(dr, ds));
    }

    // Méthode pour interdire l'accès aux demi-hexagones
    public boolean estAccessible() {
        return !estDemiHexagone;
    }
    
    // Méthode pour gérer l'ajout de vaisseaux dans un hexagone
    public void ajouterVaisseaux(int nombre) {
        if (nombre > 0) {
            this.vaisseaux += nombre;
            System.out.println(nombre + " vaisseaux ajoutés à l'hexagone " + this.id);
        } else {
            System.out.println("Impossible d'ajouter un nombre négatif ou nul de vaisseaux.");
        }
    }
    
 // Méthode pour gérer la suppression de vaisseaux dans un hexagone
    public void retirerVaisseaux(int nombre) {
        if (nombre > 0) {
            this.vaisseaux -= nombre;
            System.out.println(nombre + " vaisseaux retirés à l'hexagone " + this.id);
        } else {
            System.out.println("Impossible de retirer un nombre négatif ou nul de vaisseaux.");
        }
    }
    
    // Méthode pour déplacer des vaisseaux vers un autre hexagone
    public boolean deplacerVaisseaux(Hexagone destination, int nombre) {
        // Vérifie que le nombre de vaisseaux est valide
        if (nombre <= 0 || nombre > this.vaisseaux) {
            System.out.println("Déplacement invalide : nombre de vaisseaux incorrect.");
            return false;
        }

        // Vérifie si la destination est accessible
        if (!destination.estAccessible()) {
            System.out.println("Déplacement impossible : destination non accessible.");
            return false;
        }

        // Vérifie que la distance est valide (2 hexagones maximum)
        if (this.calculerDistance(destination) > 2) {
            System.out.println("Déplacement impossible : la destination est trop éloignée.");
            return false;
        }

        // Vérifie les règles spécifiques
        if (destination.getContrôleur() != null && !destination.getContrôleur().equals(this.contrôleur)) {
            System.out.println("Déplacement impossible : l'hexagone est occupé par un autre joueur.");
            return false;
        }

        // Déplacement des vaisseaux
        this.vaisseaux -= nombre;
        destination.ajouterVaisseaux(nombre);

        // Si la destination est un hexagone de système inoccupé, le joueur prend le contrôle
        if (destination.estHexagoneDeSystème() && destination.getContrôleur() == null) {
            destination.setContrôleur(this.contrôleur);
            System.out.println("Le joueur " + this.contrôleur.getName() + " prend le contrôle de l'hexagone " + destination.getId());
        }

        return true;
    }

    // Méthode pour obtenir le nombre de vaisseaux présents
    public int getVaisseaux() {
        return vaisseaux;
    }

    // Méthode pour vérifier si l'hexagone est inoccupé
    public boolean estInoccupé() {
        return this.vaisseaux == 0 && this.contrôleur == null;
    }

	public void setVaisseaux(int vaisseauxDéfense) {
		// TODO Auto-generated method stub
		
	}
}
