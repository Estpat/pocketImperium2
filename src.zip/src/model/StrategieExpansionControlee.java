package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Stratégie d'expansion contrôlée pour le joueur CPU.
 * Cette stratégie se concentre sur l'expansion par l'extension et l'exploration,
 * tout en gardant la possibilité d'attaquer en cas de besoin.
 */
public class StrategieExpansionControlee implements PlanificationStrategy {

    @Override
    public void planifier(JoueurCPU joueur) {
        // Création de la pile de planification avec l'ordre des cartes
        List<CommandCard> cartesExpansion = new ArrayList<>();

        // Ajouter la carte "Étendre" pour renforcer les systèmes contrôlés
        cartesExpansion.add(new Extend(joueur, 3)); // Exemples de paramètres

        // Ajouter la carte "Explorer" pour explorer les systèmes voisins
        cartesExpansion.add(new Explore(joueur, 2)); // Exemple de nombre de déplacements

        // Ajouter la carte "Exterminer" si des ennemis doivent être attaqués
        cartesExpansion.add(new Exterminate(joueur, 1)); // Exemple de nombre d'invasions possibles

        // Ajouter ces cartes à la pile de planification du joueur CPU
        joueur.getPilePlanification().clear();  // On s'assure que la pile est vide avant de l'ajouter
        joueur.getPilePlanification().addAll(cartesExpansion);
    }
}
