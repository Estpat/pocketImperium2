package model;

import java.util.*;

/**
 * Classe pour gérer la disposition des secteurs sur l'aire de jeu.
 */
public class DispositionSecteurs {
    private Secteur[][] grille; // Grille 3x3 pour les secteurs
    private Secteur triPrime; // Secteur central "Tri-Prime"
    private List<Secteur> secteursSansBande; // Secteurs sans bande bleue
    private List<Secteur> secteursAvecBande; // Secteurs avec bande bleue

    // Constructeur
    public DispositionSecteurs() {
        this.grille = new Secteur[3][3];
        this.secteursSansBande = new ArrayList<>();
        this.secteursAvecBande = new ArrayList<>();
        this.triPrime = new Secteur("Tri-Prime", true);                                                
    }

    /**
     * Initialise la disposition des secteurs selon les règles du jeu.
     */
    public void initialiserDisposition() {
        // Création des secteurs
        this.triPrime = new Secteur("Tri-Prime", true); // Secteur central
        for (int i = 0; i < 2; i++) {
            secteursSansBande.add(new Secteur("Secteur Sans Bande " + (i + 1), false));
        }
        for (int i = 0; i < 6; i++) {
            secteursAvecBande.add(new Secteur("Secteur Avec Bande " + (i + 1), false));
        }

        // Placement de Tri-Prime au centre
        grille[1][1] = triPrime;

        // Mélanger les secteurs
        Collections.shuffle(secteursSansBande);
        Collections.shuffle(secteursAvecBande);

        // Placer les secteurs sans bande autour de Tri-Prime
        grille[1][0] = secteursSansBande.remove(0); // À gauche de Tri-Prime
        grille[1][2] = secteursSansBande.remove(0); // À droite de Tri-Prime

        // Placer les secteurs avec bande pour compléter la grille
        grille[0][0] = secteursAvecBande.remove(0); // Haut-gauche
        grille[0][1] = secteursAvecBande.remove(0); // Haut-centre
        grille[0][2] = secteursAvecBande.remove(0); // Haut-droite
        grille[2][0] = secteursAvecBande.remove(0); // Bas-gauche
        grille[2][1] = secteursAvecBande.remove(0); // Bas-centre
        grille[2][2] = secteursAvecBande.remove(0); // Bas-droite

        // Vérifier et ajuster les orientations des secteurs avec bande
        ajusterOrientationDesBandes();
    }

    /**
     * Assure que les bords avec une bande bleue des secteurs sont orientés vers l'extérieur.
     */
    private void ajusterOrientationDesBandes() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                Secteur secteur = grille[i][j];
                if (secteur != null && secteursAvecBande.contains(secteur)) {
                    // Les bords extérieurs de la grille (indices 0 ou 2) doivent avoir les bandes bleues
                    boolean estSurBordExterne = (i == 0 || i == 2 || j == 0 || j == 2);
                    secteur.orienterBandesVersExterieur(estSurBordExterne);
                }
            }
        }
    }
    
    /**
     * Récupère tous les secteurs dans la disposition.
     */
    public List<Secteur> getTousLesSecteurs() {
        List<Secteur> secteurs = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (grille[i][j] != null) {
                    secteurs.add(grille[i][j]);
                }
            }
        }
        return secteurs;
    }

    /**
     * Récupère le secteur central "Tri-Prime".
     */
    public Secteur getSecteurTriPrime() {
        return triPrime;
    }

    /**
     * Affiche la disposition des secteurs pour visualisation.
     */
    public void afficherDisposition() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (grille[i][j] != null) {
                    System.out.print(grille[i][j].getNom() + "\t");
                } else {
                    System.out.print("Vide\t");
                }
            }
            System.out.println();
        }
    }
    
   
}

