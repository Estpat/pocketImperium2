package model;

import java.util.List;

/**
 * Carte de commande "Étendre".
 */
public class Extend extends CommandCard {
    private int joueursAvecCommandeEtendre; // Nombre de joueurs ayant choisi la commande "Étendre"

    // Constructeur
    public Extend (Joueur joueur, int joueursAvecCommandeEtendre) {
        super("Étendre", joueur);
        this.joueursAvecCommandeEtendre = joueursAvecCommandeEtendre;
    }

    @Override
    public void executerEffet() {
        // Récupérer les hexagones contrôlés par le joueur
        List<Hexagone> hexagonesContrôlés = getJoueur().getHexagonesContrôlés();

        if (hexagonesContrôlés.isEmpty()) {
            System.out.println("Aucun système contrôlé pour ajouter des vaisseaux.");
            return;
        }

        // Calculer le nombre de vaisseaux à ajouter (1 par joueur ayant choisi "Étendre", y compris soi-même)
        int vaisseauxÀAjouter = joueursAvecCommandeEtendre;

        System.out.println(getJoueur().getName() + " peut ajouter " + vaisseauxÀAjouter + " vaisseaux.");

        // Ajouter les vaisseaux aux systèmes contrôlés
        for (Hexagone hexagone : hexagonesContrôlés) {
            if (vaisseauxÀAjouter <= 0) break;

            // Demander combien de vaisseaux ajouter à ce système
            int ajoutPourCetHexagone = getJoueur().choisirNombreVaisseaux(hexagone, vaisseauxÀAjouter);

            if (ajoutPourCetHexagone > 0) {
                hexagone.ajouterVaisseaux(ajoutPourCetHexagone);
                vaisseauxÀAjouter -= ajoutPourCetHexagone;

                System.out.println(ajoutPourCetHexagone + " vaisseaux ajoutés au système " + hexagone.getId());
            }
        }

        if (vaisseauxÀAjouter > 0) {
            System.out.println("Tous les vaisseaux n'ont pas pu être placés. Il reste " + vaisseauxÀAjouter + " vaisseaux non placés.");
        }
    }
}
