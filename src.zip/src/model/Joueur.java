package model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * Classe abstraite représentant un joueur.
 */
public abstract class Joueur implements Serializable {
    private String nom;
    private List<CommandCard> mainCartes;
    private List<CommandCard> pilePlanification; // Pile pour l'ordre des commandes
    private List<Hexagone> hexagonesContrôlés;
    private int points;
    private int flottesRestantes;
    private boolean aGagne; 
    
    public Joueur(String nom) {
        this.nom = nom;
        this.mainCartes = new LinkedList<>();
        this.pilePlanification = new LinkedList<>();
        this.hexagonesContrôlés = new LinkedList<>();
        this.points = 0;
        this.flottesRestantes = 15; // Par exemple
        this.aGagne = false;
    }

    // Getters et méthodes communes
    public String getName() {
        return nom;
    }

    public List<CommandCard> getMainCartes() {
        return mainCartes;
    }

    public List<CommandCard> getPilePlanification() {
        return pilePlanification;
    }

    public List<Hexagone> getHexagonesContrôlés() {
        return hexagonesContrôlés;
    }

    public void ajouterCarte(CommandCard carte) {
        mainCartes.add(carte);
    }

    public void ajouterHexagone(Hexagone hexagone) {
        hexagonesContrôlés.add(hexagone);
    }

    public void retirerHexagone(Hexagone hexagone) {
        hexagonesContrôlés.remove(hexagone);
    }
    
    public abstract int choisirNombreVaisseaux(Hexagone hexagone, int vaisseauxDisponibles);

    /**
     * Phase de planification : chaque joueur décide de l'ordre des commandes.
     */
    public void planification() {
        System.out.println("Phase de planification pour le joueur " + getName() + " :");
        // Choix des cartes et mise dans la pile de planification.
        // Cela sera géré dans JoueurReel et JoueurCPU, mais cette méthode peut être générique.
    }

    /**
     * Phase d'exécution : exécution des commandes.
     */
    public void execution() {
        System.out.println("Phase d'exécution pour le joueur " + getName());
        for (CommandCard commande : pilePlanification) {
            // Logique de l'exécution des commandes, qui sera propre à chaque commande
            System.out.println("Exécution de la commande: " + commande.getNom());
        }
    }
    
    public int getPoints() {
        return points;
    }

    public void ajouterPoints(int points) {
        this.points += points;
    }

    public boolean toutesLesFlottesEliminees() {
        return flottesRestantes <= 0;
    }
    
 // Méthode pour déclarer que le joueur a gagné
    public void setAGagne(boolean aGagne) {
        this.aGagne = aGagne;
    }

	public boolean aGagne() {
		return aGagne;
	}
    	
}
