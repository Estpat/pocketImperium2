package model;

import java.util.*;

/**
 * Classe pour gérer le marquage des secteurs pendant le jeu.
 */
public class MarqueurDeSecteurs {
    private DispositionSecteurs disposition; // La disposition actuelle des secteurs
    private Set<Secteur> secteursMarqués; // Liste des secteurs déjà marqués
    private List<Joueur> joueurs; // Liste des joueurs
    private Map<Joueur, Secteur> marquages; // Marquage actuel des secteurs par joueur

    // Constructeur
    public MarqueurDeSecteurs(DispositionSecteurs disposition, List<Joueur> joueurs) {
        this.disposition = disposition;
        this.joueurs = joueurs;
        this.secteursMarqués = new HashSet<>();
        this.marquages = new HashMap<>();
    }

    /**
     * Permet aux joueurs de marquer des secteurs selon les règles.
     */
    public void marquerSecteurs() {
        for (Joueur joueur : joueurs) {
            // Obtenir les secteurs disponibles pour ce joueur
            List<Secteur> secteursDisponibles = obtenirSecteursDisponibles(joueur);

            // Si aucun secteur n'est disponible, le joueur passe son tour
            if (secteursDisponibles.isEmpty()) {
                System.out.println(joueur.getName() + " passe, aucun secteur disponible.");
                continue;
            }

            // Choisir un secteur
            Secteur secteurChoisi = choisirSecteur(joueur, secteursDisponibles);

            // Marquer le secteur
            if (secteurChoisi != null) {
                marquerSecteur(joueur, secteurChoisi);
                System.out.println(joueur.getName() + " marque le secteur " + secteurChoisi.getNom());
            }
        }

        // Si un joueur contrôle Tri-Prime, il peut marquer un secteur supplémentaire
        Joueur contrôleurTriPrime = disposition.getSecteurTriPrime().getContrôleur();
        if (contrôleurTriPrime != null) {
            List<Secteur> secteursDisponibles = obtenirSecteursDisponibles(contrôleurTriPrime);
            if (!secteursDisponibles.isEmpty()) {
                Secteur secteurSupplémentaire = choisirSecteur(contrôleurTriPrime, secteursDisponibles);
                if (secteurSupplémentaire != null) {
                    marquerSecteur(contrôleurTriPrime, secteurSupplémentaire);
                    System.out.println(contrôleurTriPrime.getName() + " contrôle Tri-Prime et marque le secteur " + secteurSupplémentaire.getNom());
                }
            }
        }
    }

    /**
     * Récupère les secteurs disponibles pour un joueur donné.
     */
    private List<Secteur> obtenirSecteursDisponibles(Joueur joueur) {
        List<Secteur> disponibles = new ArrayList<>();

        for (Secteur secteur : disposition.getTousLesSecteurs()) {
            // Conditions : le secteur ne doit pas être marqué, ne doit pas être Tri-Prime, et doit être occupé
            if (!secteursMarqués.contains(secteur)
                    && !secteur.equals(disposition.getSecteurTriPrime())
                    && secteur.estOccupe()) {
                disponibles.add(secteur);
            }
        }

        return disponibles;
    }

    /**
     * Simule le choix d'un secteur par un joueur (peut être remplacé par une logique UI ou AI).
     */
    private Secteur choisirSecteur(Joueur joueur, List<Secteur> secteursDisponibles) {
        // Ici, on choisit le premier secteur disponible (peut être modifié pour une logique plus complexe)
        return secteursDisponibles.isEmpty() ? null : secteursDisponibles.get(0);
    }

    /**
     * Marque un secteur pour un joueur.
     */
    private void marquerSecteur(Joueur joueur, Secteur secteur) {
        secteursMarqués.add(secteur);
        marquages.put(joueur, secteur);
    }

    /**
     * Affiche l'état des marquages.
     */
    public void afficherMarquages() {
        System.out.println("Marquages actuels des secteurs :");
        for (Map.Entry<Joueur, Secteur> entry : marquages.entrySet()) {
            System.out.println(entry.getKey().getName() + " a marqué le secteur " + entry.getValue().getNom());
        }
    }
}
