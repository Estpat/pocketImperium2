package model;


import java.util.List;

/**
 * Commande Explorer : Permet de déplacer les flottes d'un joueur vers d'autres hexagones.
 */
public class Explore extends CommandCard {
    private int nombreDéplacements; // Nombre de déplacements autorisés pour ce tour

    /**
     * Constructeur de la commande Explorer
     * 
     * @param joueur             Le joueur exécutant la commande
     * @param nombreDéplacements Nombre de déplacements autorisés
     */
    public Explore(Joueur joueur, int nombreDéplacements) {
        super("Explorer", joueur); // Appelle le constructeur de la classe mère CommandCard
        this.nombreDéplacements = nombreDéplacements;
    }

    @Override
    public void executerEffet() {
        Joueur joueur = getJoueur();
        System.out.println("Commande Explorer exécutée pour le joueur " + joueur.getName());
        List<Hexagone> hexagones = joueur.getHexagonesContrôlés();

        int déplacementsRestants = nombreDéplacements;

        // Parcourir les hexagones contrôlés par le joueur
        for (Hexagone hexagoneSource : hexagones) {
            if (déplacementsRestants <= 0) break; // Arrêter si plus de déplacements autorisés

            // Obtenir les voisins accessibles pour ce hexagone
            for (Hexagone voisin : hexagoneSource.getVoisins()) {
                // Vérifications avant de déplacer les vaisseaux
                if (voisin.estAccessible() && voisin.getContrôleur() == null) {
                    int vaisseauxDéplaçables = hexagoneSource.getVaisseaux();

                    if (vaisseauxDéplaçables > 0) {
                        // Déplace tous les vaisseaux disponibles de la source vers le voisin
                        hexagoneSource.deplacerVaisseaux(voisin, vaisseauxDéplaçables);

                        // Si le voisin est un système inoccupé, le joueur en prend immédiatement le contrôle
                        if (voisin.estHexagoneDeSystème() && voisin.getContrôleur() == null) {
                            voisin.setContrôleur(joueur);
                            System.out.println("Le joueur " + joueur.getName() + " prend le contrôle du système sur l'hexagone " + voisin.getId());
                        }

                        // Réduire le nombre de déplacements restants
                        déplacementsRestants--;

                        // Stopper si plus de déplacements ne sont possibles
                        if (déplacementsRestants <= 0) break;
                    }
                }
            }
        }

        if (déplacementsRestants > 0) {
            System.out.println("Tous les déplacements possibles ont été réalisés. Déplacements restants : " + déplacementsRestants);
        } else {
            System.out.println("Tous les déplacements autorisés ont été effectués.");
        }
    }
}
