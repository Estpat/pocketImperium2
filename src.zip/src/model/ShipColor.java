package model;

public enum ShipColor {
	YELLOW,
	RED,
	BLUE;
}
