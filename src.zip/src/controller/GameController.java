package controller;

import model.Partie;
import view.ConsoleView;

public class GameController {
    private Partie partie;
    private ConsoleView view;

    public GameController(Partie partie, ConsoleView view) {
        this.partie = partie;
        this.view = view;
    }

    public void lancerJeu() {
        view.afficherMessage("Bienvenue dans le jeu !");
        partie.commencer(); // Commence la partie
    }
}