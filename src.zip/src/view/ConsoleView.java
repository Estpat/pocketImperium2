package view;

import java.util.List;

import model.Joueur;
import model.MarqueurDeSecteurs;

public class ConsoleView {

	public void afficherMessage(String message) {
        System.out.println(message);
    }

    public void afficherEtatJeu(List<Joueur> joueurs, MarqueurDeSecteurs marqueurDeSecteurs) {
        // Affiche l'état actuel des joueurs et des secteurs marqués
        for (Joueur joueur : joueurs) {
            System.out.println(joueur.getName() + " a les cartes suivantes : ");
            // Afficher les cartes du joueur
        }

        marqueurDeSecteurs.afficherMarquages(); // Afficher les secteurs marqués
    }

    public void afficherTourDeJeu(Joueur joueurActuel) {
        System.out.println("C'est le tour de " + joueurActuel.getName() + " !");
    }

    public void afficherVainqueur(Joueur joueur) {
        System.out.println(joueur.getName() + " a gagné la partie !");
    }

    public void afficherErreur(String message) {
        System.out.println("Erreur: " + message);
    }
}
