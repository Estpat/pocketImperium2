package view;

public class GraphicalView {

}
